module.exports = {
    QUEEN_AMDI_OWNER: '94757405652', // Black Amda - Queen Amdi Owner
    QUEEN_AMDI_TEAM: '94719077818,94757672873,94774976567,94766426385,94711870791', // Team - Queen Amdi TEAM
    SEW_QUEEN_OWNER: '94785435462' // Ravindu Manoj - Sew Queen Owner --> For The Friendship 
};